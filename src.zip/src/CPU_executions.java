
public class CPU_executions {
    // Instruction Execution Logic
    public static String perform_action(String dataStr) {
        // Splitting the input into instruction and parameters
        String[] parts = dataStr.split("\\|");
        if (parts.length != 2) {
            return "Invalid input format";
        }
        String instruction = parts[0].trim();//Remove whitespaces if any
        String parameters = parts[1].trim();//Remove whitespaces if any
        // Extracting individual bits for parameters
        String R = parameters.substring(6, 8);
        String IX = parameters.substring(8, 10);
        String I = parameters.substring(10, 11);
        String Address = parameters.substring(11, 16); // Assuming the substring includes the 5th to the 9th index (exclusive)
        System.out.println("String R: " + R + " String IX: " + IX + " String I: " + I + " String Address: " + Address);
        int AddressDecimal = Integer.parseInt(Address, 2); //initialize address in decimal form outside of switch condition
        // Initialize values of mar and mbr in order to access memory THIS SHOULD BE DONE IN MACHINE SIMULATOR
        Memory.load(Registers.getRegisterValue("pc")); //This loads the String value of PC into MAR (FIX?)
        switch (instruction) {
            case "HLT": {
                // PRESS HALT BUTTON STOP READING INSTRUCTIONS
                break; // Don't forget to break here
            }

            case "DATA": {
                // Retrieve Current Address and Store into Memory
                System.out.println("Executing DATA instructions...");
                Memory.store(Registers.getRegisterValue("mar"), parameters);
                break; // Don't forget to break here
            }
            case "LDR": {
                // LDR r,x,address[,I] (load register from memory)
                // Opcode R  IX I Address
                // 000001 xx xx x xxxxx
                System.out.println("Executing LDR instructions...");
                // Determine if an index register is used
                switch (IX) {
                    case "01" -> {
                        // Get value at IX1 address
                        String binaryValue = Registers.getRegisterValue("ixr1");
                        int decimalValue = Integer.parseInt(binaryValue, 2);
                        AddressDecimal += decimalValue;
                        break; // Don't forget to break here
                    }
                    case "10" -> {
                        // Get value at IX2 address
                        String binaryValue = Registers.getRegisterValue("ixr2");
                        int decimalValue = Integer.parseInt(binaryValue, 2);
                        AddressDecimal += decimalValue;
                        break; // Don't forget to break here
                    }
                    case "11" -> {
                        // Get value at IX3 address
                        String binaryValue = Registers.getRegisterValue("ixr3");
                        int decimalValue = Integer.parseInt(binaryValue, 2);
                        AddressDecimal += decimalValue;
                        break; // Don't forget to break here
                    }
                }
                // Indirect/direct bit addressing
                if (I.equals("1")) {
                    // GET VALUE AT LOCATION ADDRESS_DECIMAL AND SET THAT TO NEW
//                    System.out.println("String value of AddressDecimal: " + AddressDecimal);
//                    System.out.println("Value that will be treated as the new address: " + Memory.load(String.valueOf(AddressDecimal)));
                    AddressDecimal = Integer.parseInt(Memory.load(String.valueOf(AddressDecimal)));
                }
                System.out.println("String value of AddressDecimal: " + AddressDecimal);
                System.out.println("Value at that address" + Memory.load(String.valueOf(AddressDecimal)));
                // This determines register destination of value
                switch (R) {
                    case "00" -> {
                        // Get value at IX1 address
                        Registers.setRegisterValue("gpr0", Memory.load(String.valueOf(AddressDecimal)));
                        break; // Don't forget to break here
                    }
                    case "01" -> {
                        // Get value at IX1 address
                        Registers.setRegisterValue("gpr1", Memory.load(String.valueOf(AddressDecimal)));
                        break; // Don't forget to break here
                    }
                    case "10" -> {
                        // Get value at IX2 address
                        Registers.setRegisterValue("gpr2", Memory.load(String.valueOf(AddressDecimal)));
                        break; // Don't forget to break here
                    }
                    case "11" -> {
                        // Get value at IX3 address
                        Registers.setRegisterValue("gpr3", Memory.load(String.valueOf(AddressDecimal)));
                        break; // Don't forget to break here
                    }
                }
                System.out.println("ADDRESS USED TO ACCESS VALUE:  " + String.valueOf(AddressDecimal));
                break; // Don't forget to break here
            } // End of LDR case

            case "LDA": {
                // LDA r,x,address[,I] (load register with address)
                // Opcode R  IX I Address
                // 000011 xx xx x xxxxx
                System.out.println("Executing LDA instructions...");
                // Determine if an index register is used
                switch (IX) {
                    case "01" -> {
                        // Get value at IX1 address
                        String binaryValue = Registers.getRegisterValue("ixr1");
                        int decimalValue = Integer.parseInt(binaryValue, 2);
                        AddressDecimal += decimalValue;
                        break; // Don't forget to break here
                    }
                    case "10" -> {
                        // Get value at IX2 address
                        String binaryValue = Registers.getRegisterValue("ixr2");
                        int decimalValue = Integer.parseInt(binaryValue, 2);
                        AddressDecimal += decimalValue;
                        break; // Don't forget to break here
                    }
                    case "11" -> {
                        // Get value at IX3 address
                        String binaryValue = Registers.getRegisterValue("ixr3");
                        int decimalValue = Integer.parseInt(binaryValue, 2);
                        AddressDecimal += decimalValue;
                        break; // Don't forget to break here
                    }
                }
                // Indirect/direct bit addressing
                if (I.equals("1")) {
                    // GET VALUE AT LOCATION ADDRESS_DECIMAL AND SET THAT TO NEW ADDRESS_DECIMAL
                    AddressDecimal = Integer.parseInt(Memory.load(String.valueOf(AddressDecimal)));
                }

                // This determines register destination of value
                switch (R) {
                    case "00" -> {
                        // Get value at IX1 address
                        Registers.setRegisterValue("gpr0", String.valueOf(AddressDecimal));
                        break; // Don't forget to break here
                    }
                    case "01" -> {
                        // Get value at IX1 address
                        Registers.setRegisterValue("gpr1", String.valueOf(AddressDecimal));
                        break; // Don't forget to break here
                    }
                    case "10" -> {
                        // Get value at IX2 address
                            Registers.setRegisterValue("gpr2", String.valueOf(AddressDecimal));
                        break; // Don't forget to break here
                    }
                    case "11" -> {
                        // Get value at IX3 address
                        Registers.setRegisterValue("gpr3", String.valueOf(AddressDecimal));
                        break; // Don't forget to break here
                    }
                }
                break; // Don't forget to break here
            }// End of LDA case

            case "LDX": {
                // LDX x,address[,I] (load index register from memory)
                // Opcode R  IX I Address
                // 000100 00 xx x xxxxx
                // No requirement of jumping address IX is the only register
                System.out.println("Executing LDX instructions...");
                // Indirect/direct bit addressing
                if (I.equals("1")) {
                    // GET VALUE AT LOCATION ADDRESS_DECIMAL AND SET THAT TO NEW ADDRESS_DECIMAL
                    AddressDecimal = Integer.parseInt(Memory.load(String.valueOf(AddressDecimal)));
                }

                // This determines register destination of value
                switch (IX) {
                    case "01" -> {
                        // Get value at IX1 address
                        Registers.setRegisterValue("ixr1", Memory.load(String.valueOf(AddressDecimal)));
                        break; // Don't forget to break here
                    }
                    case "10" -> {
                        // Get value at IX2 address
                        System.out.println("Target Address: " + String.valueOf(AddressDecimal));
                        System.out.println("Value at that Address: "+ Memory.load(String.valueOf(AddressDecimal)));
                        Registers.setRegisterValue("ixr2", Memory.load(String.valueOf(AddressDecimal)));
                    }
                    case "11" -> {
                        // Get value at IX3 address
                        Registers.setRegisterValue("ixr3", Memory.load(String.valueOf(AddressDecimal)));
                    }
                }
                break; // Don't forget to break here
            } // End of LDX case

            case "STR":{
                // STR r,x,address[,I] (store register memory)
                // Opcode R  IX I Address
                // 000010 xx xx x xxxxx
                switch (IX) {
                    case "01" -> {
                        // Get value at IX1 address
                        String binaryValue = Registers.getRegisterValue("ixr1");
                        int decimalValue = Integer.parseInt(binaryValue, 2);
                        AddressDecimal += decimalValue;
                        break; // Don't forget to break here
                    }
                    case "10" -> {
                        // Get value at IX2 address
                        String binaryValue = Registers.getRegisterValue("ixr2");
                        int decimalValue = Integer.parseInt(binaryValue, 2);
                        AddressDecimal += decimalValue;
                        break; // Don't forget to break here
                    }
                    case "11" -> {
                        // Get value at IX3 address
                        String binaryValue = Registers.getRegisterValue("ixr3");
                        int decimalValue = Integer.parseInt(binaryValue, 2);
                        AddressDecimal += decimalValue;
                        break; // Don't forget to break here
                    }
                }
                // Indirect/direct bit addressing
                if (I.equals("1")) {
                    // Load VALUE AT LOCATION ADDRESS_DECIMAL AND SET THAT TO NEW ADDRESS_DECIMAL
                    AddressDecimal = Integer.parseInt(Memory.load(String.valueOf(AddressDecimal)));
                }

                // This determines register destination of value
                switch (R) {
                    case "00" -> {
                        // Store specified location in memory to value in register 0
                        Memory.store(String.valueOf(AddressDecimal), Registers.getRegisterValue("gpr0"));
                        break; // Don't forget to break here
                    }
                    case "01" -> {
                        // Store value at IX1 address
                        Memory.store(String.valueOf(AddressDecimal), Registers.getRegisterValue("gpr1"));
                        break; // Don't forget to break here
                    }
                    case "10" -> {
                        // Store value at IX2 address
                        Memory.store(String.valueOf(AddressDecimal), Registers.getRegisterValue("gpr2"));
                        break; // Don't forget to break here
                    }
                    case "11" -> {
                        // Store value at IX3 address
                        Memory.store(String.valueOf(AddressDecimal), Registers.getRegisterValue("gpr3"));
                        break; // Don't forget to break here
                    }
                }
                break;
            } // End of STR case

            case "STX":{
                // STX x,address[,I] (store index register to memory)
                // Opcode R  IX I Address
                // 000101 00 xx x xxxxx

                // Indirect/direct bit addressing
                if (I.equals("1")) {
                    // Load VALUE AT LOCATION ADDRESS_DECIMAL AND SET THAT TO NEW ADDRESS_DECIMAL
                    AddressDecimal = Integer.parseInt(Memory.load(String.valueOf(AddressDecimal)));
                }

                // This determines register destination of value
                switch (IX) {
                    case "01" -> {
                        // Store value at IX1 address
                        Memory.store(String.valueOf(AddressDecimal), Registers.getRegisterValue("ixr1"));
                        break; // Don't forget to break here
                    }
                    case "10" -> {
                        // Store value at IX2 address
                        Memory.store(String.valueOf(AddressDecimal), Registers.getRegisterValue("ixr2"));
                        break; // Don't forget to break here
                    }
                    case "11" -> {
                        // Store value at IX3 address
                        Memory.store(String.valueOf(AddressDecimal), Registers.getRegisterValue("ixr3"));
                        break; // Don't forget to break here
                    }
                }
                break;
            } //End of STX case

            case "SETCCE": {
                //SETCCE r (set the E bit of condition code)
                // If c(r) = 0, the E bit of the condition code is set to 1, else the E bit of the condition code is set to 0
                // Opcode R  IX I Address
                // 100100 xx 00 0 00000
                // 100100 01 00 0 00000
                switch (R) {
                    case "00" -> {
                        // Set specified location in memory to value in register 0
                        // Set value to gpr0 address
                        String register_value = Registers.getRegisterValue("gpr0");
                        break; // Don't forget to break here
                    }
                    case "01" -> {
                        // Set value to gpr1 address
                        String register_value = Registers.getRegisterValue("gpr0");
                        break; // Don't forget to break here
                    }
                    case "10" -> {
                        // Set value to gpr2 address
                        String register_value = Registers.getRegisterValue("gpr0");
                        break; // Don't forget to break here
                    }
                    case "11" -> {
                        // Set value to gpr3 address
                        String register_value = Registers.getRegisterValue("gpr0");
                        if (areAllZero(register_value)) {
                            Registers.setRegisterValue("cc","0000000000000000");
                        } else {
                            Registers.setRegisterValue("cc","0000000000000001");
                        }
                        break; // Don't forget to break here
                    }
                }
                break;
            } //END OF SETCCE case

            case "JZ":{
                // JZ x,address[,I] (jump if zero)
                // Opcode R  IX I Address
                // 000110 00 xx x xxxxx
                String CC_value = Registers.getRegisterValue("cc");
                if (!areAllZero(CC_value)) {
                    Registers.setRegisterValue("pc", Registers.getRegisterValue("ea"));
                } // PC counter is updated in MachineSimulator normally, just need to account for when CC = 1
                break;
            }

            case "JNE":{
                // JNE r,x,address[,I] (jump if not equal)
                // Opcode R  IX I Address
                // 000111 xx xx x xxxxx
                String CC_value = Registers.getRegisterValue("cc");
                if (areAllZero(CC_value)) {
                    Registers.setRegisterValue("pc", Registers.getRegisterValue("ea"));
                } // PC counter is updated in MachineSimulator normally, just need to account for when CC = 1
                break;
            }

            case "JCC":{
                // GOING TO HAVE TO FIX THIS ONE
            }
            case "JMA":{
                // JMA x,address[,I] (unconditional jump to address)
                // Opcode R  IX I Address
                // 001001 00 xx x xxxxx
                Registers.setRegisterValue("pc", Registers.getRegisterValue("ea"));
            }
            case "JSR":{
                // JSR x,address[,I] (jump and save return address)
                // Opcode R  IX I Address
                // 001010 00 xx x xxxxx
                // This determines register destination of value
                switch (IX) {
                    case "01" -> {
                        // end PC value to IX1 address and update PC with EA
                        int pcDecimal = Integer.parseInt(Registers.getRegisterValue("pc"), 2); // Convert binary string to integer
                        pcDecimal++; // Increment the integer value
                        String incrementedPcBinary = Integer.toBinaryString(pcDecimal); // Convert incremented integer back to binary string
                        Registers.setRegisterValue("ixr1", incrementedPcBinary);
                        Registers.setRegisterValue("pc", Registers.getRegisterValue("ea"));
                        break; // Don't forget to break here
                    }
                    case "10" -> {
                        // Send PC value to IX2 address and update PC with EA
                        int pcDecimal = Integer.parseInt(Registers.getRegisterValue("pc"), 2); // Convert binary string to integer
                        pcDecimal++; // Increment the integer value
                        String incrementedPcBinary = Integer.toBinaryString(pcDecimal); // Convert incremented integer back to binary string
                        Registers.setRegisterValue("ixr1", incrementedPcBinary);
                        Registers.setRegisterValue("pc", Registers.getRegisterValue("ea"));
                        break; // Don't forget to break here
                    }
                    case "11" -> {
                        // Send PC value to IX3 address and update PC with EA
                        int pcDecimal = Integer.parseInt(Registers.getRegisterValue("pc"), 2); // Convert binary string to integer
                        pcDecimal++; // Increment the integer value
                        String incrementedPcBinary = Integer.toBinaryString(pcDecimal); // Convert incremented integer back to binary string
                        Registers.setRegisterValue("ixr1", incrementedPcBinary);
                        Registers.setRegisterValue("pc", Registers.getRegisterValue("ea"));
                        break; // Don't forget to break here
                    }
                }
                break;
            } // End of JSR case

            case "RFS":{
                // RFS Immed (return from subroutine w/ return code as Immed in instruction's address field)
                // Opcode R  IX I Address
                // 001011 11 00 0 xxxxx
            }
            case "SOB":{
                // SOB r,x,address[,I] (subtract one and branch)
                // Opcode r  IX I Address
                // 001101 xx xx x xxxxx
            }
            case "JGE":{
                // NOTHING YET
            }
            case "AMR":{
                // AMR r,x,address[,I] (add memory to register)
                // Opcode r  IX I Address
                // 001110 xx xx x xxxxx
            }
            case "SMR":{
                // SMR r,x,address[,I] (subtract memory from register)
                // Opcode r  IX I Address
                // 001111 xx xx x xxxxx
            }
            case "AIR":{
                // AIR r,Immed (add immediate to register)
                // Opcode R  IX I Address
                // 010000 xx 00 0 xxxxx
            }
            case "SIR":{
                // SIR r,Immed
                // Opcode R  IX I Address
                // 010001 xx 00 0 xxxxx
            }
            case "MLT":{
                // MLT rx,ry (multiply register by register)
                // Opcode Rx Ry ------
                // 010010 xx xx 000000
            }
            case "DVD":{
                // DVD rx,ry (divide register by register)
                // Opcode Rx Ry ------
                // 010011 xx xx 000000
            }
            case "TRR":{
                // TRR rx,ry (test the equity of register and register)
                // Opcode Rx Ry ------
                // 010100 xx xx 000000
            }
            case "AND":{
                // AND rx,ry (logical And of register and register)
                // Opcode Rx Ry ------
                // 010101 xx xx 000000
            }
            case "ORR":{
            }
            case "NOT":{
                // NOT rx (logical Not of register to register)
                // Opcode Rx Ry ------
                // 010111 xx 00 000000
            }
            case "SRC":{
                // SRC r,count,L/R,A/L (shift register by count)
                // Opcode R  A/L L/R -- Count
                // 011000 xx x   x   00 xxxx
            }
            case "RRC":{
                // RRC r,count,L/R,A/L (rotate register by count)
                // Opcode R  A/L L/R -- Count
                // 011001 xx x   x   00 xxxx
            }
            case "IN":{
                // IN r,devid (input character to register from device)
                // Opcode R  --- DevID
                // 011010 xx 000 xxxxx
            }
            case "OUT":{
                // OUT r,devid (ouput character to device from register)
                // Opcode R  --- DevID
                // 011011 xx 000 xxxxx
            }
            case "CHK":{
                // CHK r,devid (check device status to register)
                // Opcode R  --- DevID
                // 011100 xx 000 xxxxx
            }



        }
        return null;
    }
    public static boolean areAllZero(String registerValues) {
        for (int i = 0; i < registerValues.length(); i++) {
            if (registerValues.charAt(i) != '0') {
                return false;
            }
        }
        return true;
    }
}